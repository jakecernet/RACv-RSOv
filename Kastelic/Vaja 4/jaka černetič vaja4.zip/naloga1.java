/* 
Programsko bi želeli kreirati zbirko priimkov oseb. Pri tem bi želeli zagotoviti: zbirka oseb naj bo dinamična, realizirana z enostransko povezanim seznamom. 
V zbirki shranjeni priimki naj predstavljajo množico. Javni vmesnik zbirke naj predstavljajo zgolj metode prikaziZbirko1/0, prikaziZbirko2/0, dodajPriimek/1. 
PrikaziZbirko1 prikaze vse zapisane priimke od prvega do zadnjega, prikaziZbirko2 zadnjih 10 v zbirko vpisanih v obratnem časovnem vrstnem redu vpisa. 
Metoda dodajPriimek doda s parametrom podan priimek/objekt s priimkov v zbirko.

Operacije nad zbirko načrtujte tako, da bo njihova izvedba možna in če se le da, enostavna.
*/

public class naloga1 {
    public static void main(String[] args) {
        ZbirkaPriimkov zbirka = new ZbirkaPriimkov();

        zbirka.dodajPriimek("Novak");
        zbirka.dodajPriimek("Kovač");
        zbirka.dodajPriimek("Horvat");
        zbirka.dodajPriimek("Zupančič");
        zbirka.dodajPriimek("Kralj");
        zbirka.dodajPriimek("Vidmar");
        zbirka.dodajPriimek("Petek");
        zbirka.dodajPriimek("Mali");
        zbirka.dodajPriimek("Veliki");
        zbirka.dodajPriimek("Gorenjak");
        zbirka.dodajPriimek("Dolenec");

        System.out.println("Prikaz zbirke od prvega do zadnjega:");
        zbirka.prikaziZbirko1();

        System.out.println("\nPrikaz zadnjih 10 priimkov v obratnem vrstnem redu:");
        zbirka.prikaziZbirko2();
    }

    public interface Zbirka {
        void dodajPriimek(String priimek);
        void prikaziZbirko1();
        void prikaziZbirko2();
    }

    public static class ZbirkaPriimkov implements Zbirka {
        private Node head;

        private static class Node {
            String priimek;
            Node next;

            Node(String priimek) {
                this.priimek = priimek;
                this.next = null;
            }
        }

        @Override
        public void dodajPriimek(String priimek) {
            if (!contains(priimek)) {
                Node newNode = new Node(priimek);
                newNode.next = head;
                head = newNode;
            }
        }

        private boolean contains(String priimek) {
            Node current = head;
            while (current != null) {
                if (current.priimek.equals(priimek)) {
                    return true;
                }
                current = current.next;
            }
            return false;
        }

        @Override
        public void prikaziZbirko2() {
            Node current = head;
            while (current != null) {
                System.out.println(current.priimek);
                current = current.next;
            }
        }

        @Override
        public void prikaziZbirko1() {
            String[] lastTen = new String[10];
            int count = 0;

            Node current = head;
            while (current != null) {
                if (count < 10) {
                    lastTen[count] = current.priimek;
                } else {
                    for (int i = 0; i < 9; i++) {
                        lastTen[i] = lastTen[i + 1];
                    }
                    lastTen[9] = current.priimek;
                }
                count++;
                current = current.next;
            }

            for (int i = Math.min(count, 10) - 1; i >= 0; i--) {
                System.out.println(lastTen[i]);
            }
        }
    }
}
