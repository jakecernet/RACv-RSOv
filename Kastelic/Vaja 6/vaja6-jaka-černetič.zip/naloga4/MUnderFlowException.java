/**
 * Write a description of class MOverFlow here.
 * 
 * @author (your name)
 * @version (a version number or a date)
 */
public class MUnderFlowException extends Exception {

    /**
     * Constructor for objects of class MOverFlow
     */
    public MUnderFlowException() {
    }

    public MUnderFlowException(String message) {
        super(message);
    }
}